import React from 'react';
import styles from './_404.css';

export default () => {
  return (
    <div>
      <h1 className={styles.title}>Page _404</h1>
    </div>
  );
}
